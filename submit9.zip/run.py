#! /usr/bin/env python3
# -*- coding: utf-8 -*-
from datetime import datetime
import gc
from pathlib import Path
from typing import Annotated
from warnings import simplefilter
#from model_vtb import count_transform,load_models
import numpy as np
import pandas as pd
from typing import List
#from catboost import CatBoostClassifier
#from sklearn.linear_model import Ridge
#from xgboost import XGBClassifier
import typer
#import joblib
from typer import Option
import pickle
import json

from napkinxc.datasets import load_dataset
from napkinxc.models import PLT
from napkinxc.measures import precision_at_k

import polars as pl
from scipy.sparse import csr_matrix
import scipy.sparse as sp

app = typer.Typer()


def main(
  hexses_target_path: Annotated[
    Path, Option('--hexses-target-path', '-ht', dir_okay=False, help='Список локаций таргета', show_default=True, exists=True)
  ] = 'hexses_target.lst',
  hexses_data_path: Annotated[
    Path, Option('--hexses-data-path', '-hd', dir_okay=False, help='Список локаций транзакций', show_default=True, exists=True)
  ] = 'hexses_data.lst',
  input_path: Annotated[
    Path, Option('--input-path', '-i', dir_okay=False, help='Входные данные', show_default=True, exists=True)
  ] = 'moscow_transaction_data01.parquet',
  output_path: Annotated[
    Path, Option('--output-path', '-o', dir_okay=False, help='Выходные данные', show_default=True)
  ] = 'output.parquet',
):
    with open(hexses_target_path, "r") as f:
        hexses_target = [x.strip() for x in f.readlines()]
    with open(hexses_data_path, "r") as f:
        hexses_data = [x.strip() for x in f.readlines()]
        
    #transactions = pd.read_parquet(input_path)
    trans_test = pl.read_parquet(input_path)
    
    trans_train = pl.read_parquet("transactions.parquet")
    #trans_test = pl.read_parquet("trans_test.parquet")
    trans_train = trans_train.group_by("customer_id","h3_09","datetime_id","mcc_code"
                  ).agg( pl.col("count").sum().alias("count"), 
                         pl.col("sum").sum(), 
                         pl.col("min").min(), 
                         pl.col("max").max(), 
                         pl.col("count_distinct").max(), 
                        )
    trans_test = trans_test.group_by("customer_id","h3_09","datetime_id","mcc_code"
                  ).agg( pl.col("count").sum().alias("count"), 
                         pl.col("sum").sum(), 
                         pl.col("min").min(), 
                         pl.col("max").max(), 
                         pl.col("count_distinct").max(), 
                        )
        
    trans_train = trans_train.with_columns( pl.concat_str([pl.col("h3_09"), pl.col("datetime_id")]).alias("hmd") )
    trans_test = trans_test.with_columns( pl.concat_str([pl.col("h3_09"), pl.col("datetime_id")]).alias("hmd") )
     
    hmds  = (set(trans_train["hmd"].unique()).intersection( set(trans_test["hmd"].unique()) ) )
    ###################################################### tt train 
    tt = trans_train.group_by("customer_id","hmd"
                                    ).agg( pl.lit(1).alias("count") 
                                         )
    #tt = tt.with_columns( ( pl.col("count")/pl.col("count").sum().over( pl.col("customer_id") ) ).alias("count") )
    tt = tt.filter( pl.col("hmd").is_in(hmds) )
   
    unique_hmd1 = tt['hmd'].explode().unique().to_list()   
    hmd2idx1 = {vac_id: idx for idx, vac_id in enumerate(unique_hmd1)}
    idx2hmd1 = {idx: vac_id for vac_id, idx in hmd2idx1.items()}    
    
    unique_cu = tt['customer_id'].unique().to_list()
    cu2idx = {user_id: idx for idx, user_id in enumerate(unique_cu)}
    idx2cu = {idx: vac_id for vac_id, idx in cu2idx.items()}
    ################################################### count train
    pairs = tt.select(['customer_id', 'hmd', 'count'])
    users = pairs['customer_id'].replace(cu2idx).to_numpy()
    vacancies = pairs['hmd'].replace(hmd2idx1).to_numpy()
    preferences = pairs['count'].cast(pl.Float32).to_numpy()

    cutran_mat_1train = csr_matrix((preferences, (users, vacancies)), 
                              shape=(len(unique_cu), len(hmd2idx1)), 
                              dtype=np.float32)     
    ################################################### # target
    targ2idx = {vac_id: idx for idx, vac_id in enumerate(hexses_target)}
    idx2targ = {idx: vac_id for vac_id, idx in targ2idx.items()}
    targe = pl.read_parquet("target.parquet")
    targ = targe.with_columns( pl.col("h3_09").replace(targ2idx).cast(pl.Int16), pl.col("customer_id").replace(cu2idx).cast(pl.Int32))
    targ = targ.group_by("customer_id").agg( pl.col("h3_09").unique() ).sort("customer_id")["h3_09"].to_list()
    
    
    plt = PLT("eurlex-model2")
    #plt.fit(cutran_mat_1train, targ, )
    plt.load()
    
    #############################################################################################
    ##### tt count test
    tt = trans_test.group_by("customer_id","hmd"
                                    ).agg( pl.lit(1).alias("count") 
                                         )
    #tt = tt.with_columns( ( pl.col("count")/pl.col("count").sum().over( pl.col("customer_id") ) ).alias("count") )
    tt = tt.filter( pl.col("hmd").is_in(hmds) )
    unique_cu = tt['customer_id'].unique().to_list()
    cu2idx = {user_id: idx for idx, user_id in enumerate(unique_cu)}
    idx2cu = {idx: vac_id for vac_id, idx in cu2idx.items()}
    ##### count
    pairs = tt.select(['customer_id', 'hmd', 'count'])
    users = pairs['customer_id'].replace(cu2idx).to_numpy()
    vacancies = pairs['hmd'].replace(hmd2idx1).to_numpy()
    preferences = pairs['count'].cast(pl.Float32).to_numpy()

    cutran_mat_1test = csr_matrix((preferences, (users, vacancies)), 
                              shape=(len(unique_cu), len(hmd2idx1)), 
                              dtype=np.float32)
    ###############################################################################################
    predi = plt.predict_proba(cutran_mat_1test, top_k=1657)
    cus=[]
    h3s=[]
    prs=[]
    icu=0
    for cu in predi:
        for h3 in cu:
            cus.append(icu)
            h3s.append(h3[0])
            prs.append(h3[1])
        icu+=1
    dfpred = pd.DataFrame( csr_matrix((prs, (cus, h3s))).toarray(), columns=idx2targ.values() )
    for col in hexses_target:
        if not col in dfpred.columns:
            #print("dfpred",col)
            dfpred[col]=0.0011
    dfpred['customer_id'] = dfpred.index.map(idx2cu)    
    dfpred.to_parquet(output_path)

if __name__ == '__main__':
  typer.run(main, )
